from django.contrib import admin
from django.urls import path, include
from django.views.generic import ListView, DetailView
from tm_Project.models import Tm_Prject
from tm_Project.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('tm/', include('tm_Project.urls'))
]
