import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import oracledb as orcl
import plotly.express as px
import plotly.graph_objects as go
from sqlalchemy import create_engine

orcl.init_oracle_client()

# 최근 6개월동안 출시된 상품 은행별 개수
def chart1():   
    # oracle 서버에 연결
    con = orcl.connect(
    user='chatbot',
    password='12345',
    dsn='localhost:1521/xe'
    )

    cur = con.cursor()
    select_query = 'SELECT DISTINCT(product_bank) FROM product_info'
    cur.execute(select_query)
    result = cur.fetchall()
    column_name = ['product_bank']
    df = pd.DataFrame(result, columns=column_name)

    # DataFrame의 값을 리스트로 변환
    product_banks = df['product_bank'].tolist()
    bank_cnt = []
    for bank in product_banks:
        select_query = 'SELECT * FROM product_info WHERE product_bank = :bank'
        cur.execute(select_query, bank=bank)
        bank_result = cur.fetchall()
        bank_cnt.append(len(bank_result))

    banks = product_banks
    counts = bank_cnt
    
    bar_colors = ['tab:red', 'tab:blue', 'tab:red', 'tab:orange']
    df = pd.DataFrame({'banks': banks, 'counts': counts})

    fig = px.bar(df, x='banks', y='counts', color='counts', hover_name='banks')

    # 그래프에 제목 추가
    fig.update_layout(
        title='최근 6개월 동안 출시된 은행별 상품 개수',
        title_x=0.5  # 제목을 중앙에 배치
    )

    plot_tag = fig.to_html(full_html=False)

    con.close()
    return plot_tag

def chart2():
    # Oracle 클라이언트 초기화 (필요에 따라 경로 지정)
    orcl.init_oracle_client()

    # Oracle 서버에 연결
    con = orcl.connect(
        user='chatbot',
        password='12345',
        dsn='localhost:1521/xe'
    )

    # 커서 생성
    cur = con.cursor()

    # 차트 내용 세팅
    character = ['bank']
    parent = ['']
    value = []
    value_tmp = []

    # 은행 이름 가져오기
    bankName_List = []

    select_query = """
    SELECT
        DISTINCT(product_bank)
    FROM
        product_info
    """
    cur.execute(select_query)
    result = cur.fetchall()
    df = pd.DataFrame(result)

    bankName_List = [row[0] for row in result]
    for bank_NAME in bankName_List:
        character.append(bank_NAME)
        parent.append('bank')
    value.append(len(bankName_List))    # 전체 은행 개수

    # 은행별 상품 개수 넣기
    for bank_name in bankName_List:
            select_query = """
            SELECT
                COUNT(product_name)
            FROM
                product_info
            WHERE
                product_bank = :1
            """
            cur.execute(select_query, (bank_name,))
            result = cur.fetchall()
            df = pd.DataFrame(result)
            
            bankProduct_cnt = [row[0] for row in result]
            for vProdcut_cnt in bankProduct_cnt:
                value.append(vProdcut_cnt)

    # 은행별 세부 종목 넣기
    for bank_name in bankName_List:
        select_query = """
        SELECT
            DISTINCT(product_type)
        FROM
            product_info
        WHERE
            product_bank = :1
        """
        cur.execute(select_query, (bank_name,))
        result = cur.fetchall()
        df = pd.DataFrame(result)
        banksubProduct_cnt = [row[0] for row in result]
        

        for vbanksubProduct_cnt in banksubProduct_cnt:
            character.append(vbanksubProduct_cnt)
            parent.append(bank_name)
            value_tmp.append(vbanksubProduct_cnt)

    # 은행별 세부 종목 개수 넣기
    for bank_name in bankName_List:
        select_query = """
        SELECT
            DISTINCT(product_type)
        FROM
            product_info
        WHERE
            product_bank = :1
        """
        cur.execute(select_query, (bank_name,))
        result = cur.fetchall()
        df = pd.DataFrame(result)
        banksubProduct_cnt = [row[0] for row in result]

        for bank_sub in banksubProduct_cnt:
            select_query = """
            SELECT
                COUNT(product_type)
            FROM
                product_info
            WHERE
                product_bank = :1
                AND product_type = :2
            """
            cur.execute(select_query, (bank_name, bank_sub))
            result = cur.fetchall()
            df = pd.DataFrame(result)
            value_tmp = [row[0] for row in result]
            value.append(value_tmp[0])

    # 데이터 프레임 생성
    data = pd.DataFrame({
        'character': character,
        'parent': parent,
        'value': value
    })

    fig = px.sunburst(
        data,
        names='character',
        parents='parent',
        values='value',
    )

    # 그래프에 제목 및 크기 추가
    fig.update_layout(
        title='최근 6개월 동안 출시된 상품 유형 개수',
        width=800,  # 차트 너비
        height=800,  # 차트 높이
        title_x=0.5,  # 제목을 중앙에 배치
    )

    plot_tag = fig.to_html(full_html=False)

    con.close()
    return plot_tag

def chart2sm():
    # Oracle 클라이언트 초기화 (필요에 따라 경로 지정)
    orcl.init_oracle_client()

    # Oracle 서버에 연결
    con = orcl.connect(
        user='chatbot',
        password='12345',
        dsn='localhost:1521/xe'
    )

    # 커서 생성
    cur = con.cursor()

    # 차트 내용 세팅
    character = ['bank']
    parent = ['']
    value = []
    value_tmp = []

    # 은행 이름 가져오기
    bankName_List = []

    select_query = """
    SELECT
        DISTINCT(product_bank)
    FROM
        product_info
    """
    cur.execute(select_query)
    result = cur.fetchall()
    df = pd.DataFrame(result)

    bankName_List = [row[0] for row in result]
    for bank_NAME in bankName_List:
        character.append(bank_NAME)
        parent.append('bank')
    value.append(len(bankName_List))    # 전체 은행 개수

    # 은행별 상품 개수 넣기
    for bank_name in bankName_List:
            select_query = """
            SELECT
                COUNT(product_name)
            FROM
                product_info
            WHERE
                product_bank = :1
            """
            cur.execute(select_query, (bank_name,))
            result = cur.fetchall()
            df = pd.DataFrame(result)
            
            bankProduct_cnt = [row[0] for row in result]
            for vProdcut_cnt in bankProduct_cnt:
                value.append(vProdcut_cnt)

    # 은행별 세부 종목 넣기
    for bank_name in bankName_List:
        select_query = """
        SELECT
            DISTINCT(product_type)
        FROM
            product_info
        WHERE
            product_bank = :1
        """
        cur.execute(select_query, (bank_name,))
        result = cur.fetchall()
        df = pd.DataFrame(result)
        banksubProduct_cnt = [row[0] for row in result]
        

        for vbanksubProduct_cnt in banksubProduct_cnt:
            character.append(vbanksubProduct_cnt)
            parent.append(bank_name)
            value_tmp.append(vbanksubProduct_cnt)

    # 은행별 세부 종목 개수 넣기
    for bank_name in bankName_List:
        select_query = """
        SELECT
            DISTINCT(product_type)
        FROM
            product_info
        WHERE
            product_bank = :1
        """
        cur.execute(select_query, (bank_name,))
        result = cur.fetchall()
        df = pd.DataFrame(result)
        banksubProduct_cnt = [row[0] for row in result]

        for bank_sub in banksubProduct_cnt:
            select_query = """
            SELECT
                COUNT(product_type)
            FROM
                product_info
            WHERE
                product_bank = :1
                AND product_type = :2
            """
            cur.execute(select_query, (bank_name, bank_sub))
            result = cur.fetchall()
            df = pd.DataFrame(result)
            value_tmp = [row[0] for row in result]
            value.append(value_tmp[0])

    # 데이터 프레임 생성
    data = pd.DataFrame({
        'character': character,
        'parent': parent,
        'value': value
    })

    fig = px.sunburst(
        data,
        names='character',
        parents='parent',
        values='value',
    )

    # 그래프에 제목 및 크기 추가
    fig.update_layout(
        title_x=0.5,  # 제목을 중앙에 배치
    )

    plot_tag = fig.to_html(full_html=False)

    con.close()
    return plot_tag

def chart3():
    orcl.init_oracle_client()

   # Oracle 서버에 연결
    con = orcl.connect(
        user='chatbot',
        password='12345',
        dsn='localhost:1521/xe'
    )

    # 커서 생성
    cur = con.cursor()
    x_value = []
    y_value = []

    select_query = """
    SELECT 
        DISTINCT TO_CHAR(kor_co_nm)
    FROM 
        "SavingBase"
    """
    cur.execute(select_query)
    result = cur.fetchall()
    df = pd.DataFrame(result)
    value_tmp = [row[0] for row in result]
    for value_test in value_tmp:
        x_value.append(value_test)

    for bank_name in x_value:
        select_query = """
        SELECT  
            ROUND(AVG(TO_NUMBER(sbo.intr_rate)), 2) AS avg_interest_rate
        FROM 
            "SavingBase" sb, "SavingOption" sbo
        WHERE
            TO_CHAR(sb.fin_prdt_cd) = TO_CHAR(sbo.fin_prdt_cd) AND
            TO_CHAR(kor_co_nm) = :1
        GROUP BY 
            TO_CHAR(sb.kor_co_nm)
        """
        cur.execute(select_query, (bank_name,))
        result = cur.fetchall()
        df = pd.DataFrame(result)
        banksubProduct_cnt = [row[0] for row in result]
        for value_tmp in banksubProduct_cnt:
            y_value.append(value_tmp)

    marker_size = [value * 10 for value in y_value]

    fig = go.Figure(data=[go.Scatter(
    x = x_value,
    y = y_value,
    mode='markers',
    marker=dict(
        color = y_value,
        size = marker_size,
        showscale=True
        )
    )])

    # 그래프에 제목 및 크기 추가
    fig.update_layout(
        title='은행별 상품 평균 저축 금리',
        title_x=0.5,  # 제목을 중앙에 배치
        width=800,  # 차트 너비
        height=800  # 차트 높이
    )

    plot_tag = fig.to_html(full_html=False)

    return plot_tag

def chart3sm():
    orcl.init_oracle_client()

   # Oracle 서버에 연결
    con = orcl.connect(
        user='chatbot',
        password='12345',
        dsn='localhost:1521/xe'
    )

    # 커서 생성
    cur = con.cursor()
    x_value = []
    y_value = []

    select_query = """
    SELECT 
        DISTINCT TO_CHAR(kor_co_nm)
    FROM 
        "SavingBase"
    """
    cur.execute(select_query)
    result = cur.fetchall()
    df = pd.DataFrame(result)
    value_tmp = [row[0] for row in result]
    for value_test in value_tmp:
        x_value.append(value_test)

    for bank_name in x_value:
        select_query = """
        SELECT  
            ROUND(AVG(TO_NUMBER(sbo.intr_rate)), 2) AS avg_interest_rate
        FROM 
            "SavingBase" sb, "SavingOption" sbo
        WHERE
            TO_CHAR(sb.fin_prdt_cd) = TO_CHAR(sbo.fin_prdt_cd) AND
            TO_CHAR(kor_co_nm) = :1
        GROUP BY 
            TO_CHAR(sb.kor_co_nm)
        """
        cur.execute(select_query, (bank_name,))
        result = cur.fetchall()
        df = pd.DataFrame(result)
        banksubProduct_cnt = [row[0] for row in result]
        for value_tmp in banksubProduct_cnt:
            y_value.append(value_tmp)

    marker_size = [value * 10 for value in y_value]

    fig = go.Figure(data=[go.Scatter(
    x = x_value,
    y = y_value,
    mode='markers',
    marker=dict(
        color = y_value,
        size = marker_size,
        showscale=True
        )
    )])

    # 그래프에 제목 및 크기 추가
    fig.update_layout(
        title='은행별 상품 평균 저축 금리',
        title_x=0.5,  # 제목을 중앙에 배치
        width=500,  # 차트 너비
        height=500  # 차트 높이
    )

    plot_tag = fig.to_html(full_html=False)

    return plot_tag

def depositchart():
    # 데이터베이스 연결 설정
    path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
    orcl.init_oracle_client()
    engine = create_engine(path)

    df1 = pd.read_sql("""SELECT * FROM "DepositOption" """, engine)
    df2 = pd.read_sql("""SELECT * FROM "DepositBase" """, engine)
    
    df1 = df1[['fin_prdt_cd','intr_rate_type_nm', 'intr_rate']]
    df2 = df2[['fin_prdt_cd', 'kor_co_nm']]

    merged_df = pd.merge(df1, df2, on='fin_prdt_cd', how='outer')
    merged_df = merged_df.rename(columns={'fin_prdt_cd' : '상품코드', 'intr_rate_type_nm' : '금리유형', 'intr_rate' : '저축금리', 'kor_co_nm' : '은행이름'})

    merged_df['저축금리'] = merged_df['저축금리'].astype(float)

    # 은행별 평균 금리 계산
    avg_rate_per_bank = merged_df.groupby('은행이름')['저축금리'].mean().reset_index()

    # 은행별 정기예금 저축금리 상위 20개만 선택
    top_20_banks = avg_rate_per_bank.nlargest(20, '저축금리')

    # 시각화
    fig = px.bar(top_20_banks, x='은행이름', y='저축금리', title='은행별 정기예금 평균저축금리 상위 20위', color='은행이름',
                 labels={'은행이름': '은행이름', '저축금리': '은행별 평균 저축금리'}, text='저축금리')

    # 레이아웃 수정
    fig.update_layout(title_x = 0.5, width=1000, height=700)

    # 데이터 레이블 표시(표시 형식, 위치할 곳, 글자 크기)
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='inside', textfont=dict(size=20))

    # 그래프 HTML 반환
    plot = fig.to_html(full_html=False)

    return plot

def depositchartsm():
    # 데이터베이스 연결 설정
    path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
    orcl.init_oracle_client()
    engine = create_engine(path)

    df1 = pd.read_sql("""SELECT * FROM "DepositOption" """, engine)
    df2 = pd.read_sql("""SELECT * FROM "DepositBase" """, engine)
    
    df1 = df1[['fin_prdt_cd','intr_rate_type_nm', 'intr_rate']]
    df2 = df2[['fin_prdt_cd', 'kor_co_nm']]

    merged_df = pd.merge(df1, df2, on='fin_prdt_cd', how='outer')
    merged_df = merged_df.rename(columns={'fin_prdt_cd' : '상품코드', 'intr_rate_type_nm' : '금리유형', 'intr_rate' : '저축금리', 'kor_co_nm' : '은행이름'})

    merged_df['저축금리'] = merged_df['저축금리'].astype(float)

    # 은행별 평균 금리 계산
    avg_rate_per_bank = merged_df.groupby('은행이름')['저축금리'].mean().reset_index()

    # 은행별 정기예금 저축금리 상위 20개만 선택
    top_20_banks = avg_rate_per_bank.nlargest(20, '저축금리')

    # 시각화
    fig = px.bar(top_20_banks, x='은행이름', y='저축금리', title='은행별 정기예금 평균저축금리 상위 20위', color='은행이름',
                 labels={'은행이름': '은행이름', '저축금리': '은행별 평균 저축금리'}, text='저축금리')

    # 레이아웃 수정
    fig.update_layout(title_x = 0.5, width=600, height=300)

    # 데이터 레이블 표시(표시 형식, 위치할 곳, 글자 크기)
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='inside', textfont=dict(size=20))

    # 그래프 HTML 반환
    plot = fig.to_html(full_html=False)

    return plot

def savingchart():
    # 데이터베이스 연결 설정
    path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
    orcl.init_oracle_client()
    engine = create_engine(path)

    # SQL 쿼리 작성
    query = """
        SELECT 
            to_char(so.intr_rate_type_nm) 금리유형,
            round(AVG(TO_number(so.intr_rate)),2) 평균저축금리,
            to_char(so.rsrv_type_nm) 저축유형
        FROM
            "SavingOption" so
        GROUP BY
            to_char(so.intr_rate_type_nm),
            to_char(so.rsrv_type_nm)
    """


    df = pd.read_sql_query(query, con=engine)

    df = df.astype({'평균저축금리' : float})

    fig = px.bar(df, x='금리유형', y="평균저축금리", hover_name="저축유형", color="평균저축금리", hover_data=['금리유형', '저축유형'],
                 title="적금 금리유형 별 평균저축금리", text='평균저축금리', barmode="group")
    
    # 레이아웃 수정: 제목 가운데 정렬
    fig.update_layout(title_x=0.5, width = 800, height = 700)

    # 데이터 레이블 표시(표시 형식, 위치할 곳, 글자 크기)
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='inside', textfont=dict(size=20))
    
    # 그래프 표시
    plot = fig.to_html(full_html = False)

    return plot

def savingchartsm():
    # 데이터베이스 연결 설정
    path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
    orcl.init_oracle_client()
    engine = create_engine(path)

    # SQL 쿼리 작성
    query = """
        SELECT 
            to_char(so.intr_rate_type_nm) 금리유형,
            round(AVG(TO_number(so.intr_rate)),2) 평균저축금리,
            to_char(so.rsrv_type_nm) 저축유형
        FROM
            "SavingOption" so
        GROUP BY
            to_char(so.intr_rate_type_nm),
            to_char(so.rsrv_type_nm)
    """


    df = pd.read_sql_query(query, con=engine)

    df = df.astype({'평균저축금리' : float})

    fig = px.bar(df, x='금리유형', y="평균저축금리", hover_name="저축유형", color="평균저축금리", hover_data=['금리유형', '저축유형'],
                 title="적금 금리유형 별 평균저축금리", text='평균저축금리', barmode="group")
    
    # 레이아웃 수정: 제목 가운데 정렬
    fig.update_layout(title_x=0.5, width = 500, height = 400)

    # 데이터 레이블 표시(표시 형식, 위치할 곳, 글자 크기)
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='inside', textfont=dict(size=20))
    
    # 그래프 표시
    plot = fig.to_html(full_html = False)

    return plot

def annuitychartsm(): # 연금저축
    # 데이터베이스 연결 설정
    path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
    orcl.init_oracle_client()
    engine = create_engine(path)

    # SQL 쿼리 작성
    query = """
        SELECT DISTINCT
            to_char(AVG_PRFT_RATE) AS 평균수익률, 
            to_char(kor_co_nm) AS 운영회사, 
            to_char(fin_prdt_nm) AS 상품이름
        FROM
            "AnnuitysavingBase"
        WHERE
            to_char(PRDT_TYPE_NM) = '금리연동형'
        ORDER BY
            운영회사
    """

    # SQL 쿼리 실행
    df = pd.read_sql_query(query, con=engine)

    df = df.astype({'평균수익률' : float})
    
    # Plotly를 사용하여 막대 그래프 생성
    fig = px.bar(df, x='운영회사', y='평균수익률', title='금융회사별 금리연동형 연금저축상품의 평균수익률', hover_name='상품이름', 
                color="운영회사", hover_data=['운영회사','상품이름'], text='평균수익률')

    

    # 레이아웃 수정: 제목 가운데 정렬
    fig.update_layout(title_x=0.5, width = 600 , height = 350)

    # 데이터 레이블 표시(표시 형식, 위치할 곳, 글자 크기)
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='inside',textfont=dict(size=12))

    plot = fig.to_html(full_html = False)
    return plot

def annuitychart(): # 연금저축
    # 데이터베이스 연결 설정
    path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
    orcl.init_oracle_client()
    engine = create_engine(path)

    # SQL 쿼리 작성
    query = """
        SELECT DISTINCT
            to_char(AVG_PRFT_RATE) AS 평균수익률, 
            to_char(kor_co_nm) AS 운영회사, 
            to_char(fin_prdt_nm) AS 상품이름
        FROM
            "AnnuitysavingBase"
        WHERE
            to_char(PRDT_TYPE_NM) = '금리연동형'
        ORDER BY
            운영회사
    """

    # SQL 쿼리 실행
    df = pd.read_sql_query(query, con=engine)

    df = df.astype({'평균수익률' : float})
    
    # Plotly를 사용하여 막대 그래프 생성
    fig = px.bar(df, x='운영회사', y='평균수익률', title='금융회사별 금리연동형 연금저축상품의 평균수익률', hover_name='상품이름', 
                color="운영회사", hover_data=['운영회사','상품이름'], text='평균수익률')

    

    # 레이아웃 수정: 제목 가운데 정렬
    fig.update_layout(title_x=0.5, width = 1000 , height = 750)

    # 데이터 레이블 표시(표시 형식, 위치할 곳, 글자 크기)
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='inside',textfont=dict(size=12))

    plot = fig.to_html(full_html = False)
    return plot