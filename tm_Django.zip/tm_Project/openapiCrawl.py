import requests as req
import pandas as pd
from sqlalchemy import create_engine
import oracledb as orcl
import time

def deposit(): # 정기예금
    pageno = 1 # 페이지 번호 초기화
    url = 'http://finlife.fss.or.kr/finlifeapi/' # URL
    product_type = 'depositProductsSearch.json'
    topFinGrpNo = ['020000', '030200', '030300', '050000', '060000'] # 은행, 여신전문, 저축은행, 보험, 금융투자
    key = '748fe783d4430e67ff729e114b4b73a8' # 인증키
    base_list = [] # 기본정보 리스트
    option_list = [] # 추가정보 리스트
    mainurl = url + product_type

    for b in topFinGrpNo: # 권역코드 반복
        parameter = {
            'auth': key, # 인증키
            'topFinGrpNo': b, # 권역코드
            'pageNo': pageno # 페이지 번호
        }
            
        response = req.get(mainurl, params=parameter).json()
        maxpage = response['result']['max_page_no'] # 최대 페이지 번호
        
        for c in range(1, maxpage + 1):
            finalparam = {
                'auth': key, # 인증키
                'topFinGrpNo': b, # 권역코드
                'pageNo': c # 페이지 번호
            }
            result = req.get(mainurl, params=finalparam).json()
            base = result['result']['baseList'] # 기본정보
            option = result['result']['optionList'] # 추가정보
                
            base_list.extend(base)
            option_list.extend(option)
    
        df_base = pd.DataFrame(base_list)
        df_option = pd.DataFrame(option_list)
        
    depositbaseinsert(df_base)
    depositoptioninsert(df_option)

def saving(): # 적금
    pageno = 1 # 페이지 번호 초기화
    url = 'http://finlife.fss.or.kr/finlifeapi/' # URL
    product_type = 'savingProductsSearch.json'
    topFinGrpNo = ['020000', '030200', '030300', '050000', '060000'] # 은행, 여신전문, 저축은행, 보험, 금융투자
    key = '748fe783d4430e67ff729e114b4b73a8' # 인증키
    base_list = [] # 기본정보 리스트
    option_list = [] # 추가정보 리스트
    mainurl = url + product_type

    for b in topFinGrpNo: # 권역코드 반복
        parameter = {
            'auth': key, # 인증키
            'topFinGrpNo': b, # 권역코드
            'pageNo': pageno # 페이지 번호
        }
            
        response = req.get(mainurl, params=parameter).json()
        maxpage = response['result']['max_page_no'] # 최대 페이지 번호
            
        for c in range(1, maxpage + 1):
            finalparam = {
                'auth': key, # 인증키
                'topFinGrpNo': b, # 권역코드
                'pageNo': c # 페이지 번호
            }
            result = req.get(mainurl, params=finalparam).json()
            base = result['result']['baseList'] # 기본정보
            option = result['result']['optionList'] # 추가정보
                
            base_list.extend(base)
            option_list.extend(option)
    
        df_base = pd.DataFrame(base_list)
        df_option = pd.DataFrame(option_list)

    savingbaseinsert(df_base)
    savingoptioninsert(df_option)

def annuitysaving(): # 연금저축
    pageno = 1 # 페이지 번호 초기화
    url = 'http://finlife.fss.or.kr/finlifeapi/' # URL
    product_type = 'annuitySavingProductsSearch.json'
    topFinGrpNo = ['020000', '030200', '030300', '050000', '060000'] # 은행, 여신전문, 저축은행, 보험, 금융투자
    key = '748fe783d4430e67ff729e114b4b73a8' # 인증키
    base_list = [] # 기본정보 리스트
    option_list = [] # 추가정보 리스트
    mainurl = url + product_type

    for b in topFinGrpNo: # 권역코드 반복
        parameter = {
            'auth': key, # 인증키
            'topFinGrpNo': b, # 권역코드
            'pageNo': pageno # 페이지 번호
        }
            
        response = req.get(mainurl, params=parameter).json()
        maxpage = response['result']['max_page_no'] # 최대 페이지 번호
            
        for c in range(1, maxpage + 1):
            finalparam = {
                'auth': key, # 인증키
                'topFinGrpNo': b, # 권역코드
                'pageNo': c # 페이지 번호
            }
            result = req.get(mainurl, params=finalparam).json()
            base = result['result']['baseList'] # 기본정보
            option = result['result']['optionList'] # 추가정보
                
            base_list.extend(base)
            option_list.extend(option)
    
        df_base = pd.DataFrame(base_list)
        df_option = pd.DataFrame(option_list)

    annuitysavingbaseinsert(df_base)
    annuitysavingoptioninsert(df_option)

def depositbaseinsert(db):
    depositbase = db
    try:
        depositbase = depositbase.applymap(str)

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
        orcl.init_oracle_client()
        engine = create_engine(path)

        print("데이터베이스 접속 완료")

        depositbase.to_sql(
            name='DepositBase',
            con=engine,
            if_exists='replace',  # 테이블이 존재하지 않으면 생성, 존재하면 데이터 추가
            index=False,
        )
        print("데이터 삽입 완료")
    except Exception as e:
        print(f"데이터베이스 작업 오류: {e}")

def depositoptioninsert(do):
    depositoption = do
    try:
        depositoption = depositoption.applymap(str)

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
        orcl.init_oracle_client()
        engine = create_engine(path)

        print("데이터베이스 접속 완료")

        depositoption.to_sql(
            name='DepositOption',
            con=engine,
            if_exists='replace',  # 테이블이 존재하지 않으면 생성, 존재하면 데이터 추가
            index=False,
        )
        print("데이터 삽입 완료")
    except Exception as e:
        print(f"데이터베이스 작업 오류: {e}")

def savingbaseinsert(sb):
    savingbase = sb
    try:
        savingbase = savingbase.applymap(str)

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
        orcl.init_oracle_client()
        engine = create_engine(path)

        print("데이터베이스 접속 완료")

        savingbase.to_sql(
            name='SavingBase',
            con=engine,
            if_exists='replace',  # 테이블이 존재하지 않으면 생성, 존재하면 데이터 추가
            index=False,
        )
        print("데이터 삽입 완료")
    except Exception as e:
        print(f"데이터베이스 작업 오류: {e}")

def savingoptioninsert(so):
    savingoption = so
    try:
        savingoption = savingoption.applymap(str)

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
        orcl.init_oracle_client()
        engine = create_engine(path)

        print("데이터베이스 접속 완료")

        savingoption.to_sql(
            name='SavingOption',
            con=engine,
            if_exists='replace',  # 테이블이 존재하지 않으면 생성, 존재하면 데이터 추가
            index=False,
        )
        print("데이터 삽입 완료")
    except Exception as e:
        print(f"데이터베이스 작업 오류: {e}")

def annuitysavingbaseinsert(ab):
    annuitysavingbase = ab
    try:
        annuitysavingbase = annuitysavingbase.applymap(str)

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
        orcl.init_oracle_client()
        engine = create_engine(path)

        print("데이터베이스 접속 완료")

        annuitysavingbase.to_sql(
            name='AnnuitysavingBase',
            con=engine,
            if_exists='replace',  # 테이블이 존재하지 않으면 생성, 존재하면 데이터 추가
            index=False,
        )
        print("데이터 삽입 완료")
    except Exception as e:
        print(f"데이터베이스 작업 오류: {e}")

def annuitysavingoptioninsert(ao):
    annuitysavingoption = ao
    try:
        annuitysavingoption = annuitysavingoption.applymap(str)

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe'
        orcl.init_oracle_client()
        engine = create_engine(path)

        print("데이터베이스 접속 완료")

        annuitysavingoption.to_sql(
            name='AnnuitysavingOption',
            con=engine,
            if_exists='replace',  # 테이블이 존재하지 않으면 생성, 존재하면 데이터 추가
            index=False,
        )
        print("데이터 삽입 완료")
    except Exception as e:
        print(f"데이터베이스 작업 오류: {e}")

crawlDict = {
    '정기예금' : deposit,
    '적금' : saving,
    '연금저축' : annuitysaving,
}

def Crawling():
    k = crawlDict.keys()
    for key in k:
        crawlDict[key]()