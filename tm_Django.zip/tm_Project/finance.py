from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import pandas as pd
from sqlalchemy import create_engine
import oracledb as orcl

# 데이터 크롤링 함수
def DataCrawl():
    # 크롬 드라이버 설정 및 웹 페이지 접속
    driver = webdriver.Chrome()
    driver.get('https://portal.kfb.or.kr/fingoods/new_goods.php')

    # 페이지 개수 계산
    page_cntList = driver.find_elements(By.CSS_SELECTOR, '.pageArea a')
    page_Cnt = len(page_cntList) + 1

    # 데이터 크롤링해서 추출한 데이터를 받아서 넣을 리스트
    products_List = []
    num = 1000

    for i in range(1, page_Cnt):
        url_cntList = driver.find_elements(By.CSS_SELECTOR, '.resultList_ty01 > tbody a')
        url_Cnt = len(url_cntList)
        print(url_Cnt)

        for j in range(url_Cnt):
            elements = driver.find_elements(By.CSS_SELECTOR, '.resultList_ty01 .taWid_title_1 a')
            if j < len(elements):
                try:
                    elements[j].click()
                    num += 1

                    # 은행 이름
                    bank = driver.find_element(By.CSS_SELECTOR, '.contentArea > .panViewArea > .viewInfo > .title > span').text
                    start = bank.find('[') + 1
                    end = bank.find(']')
                    product_bank = bank[start:end]

                    # 상품명
                    name = driver.find_element(By.CSS_SELECTOR, '.contentArea > .panViewArea > .viewInfo > .title').text
                    start = name.find(',') + 1
                    product_Name = name[start:]

                    # 출시일
                    release = driver.find_element(By.CSS_SELECTOR, '.contentArea > .panViewArea > .viewInfo > .item > :nth-last-child(1)').text
                    end = release.find('~') - 1
                    product_Release = release[:end]

                    # 제품 설명서
                    body = driver.find_element(By.CSS_SELECTOR, '.contentArea > .panViewArea > .viewInfo > .txt').text
                    product_body = body

                    # 제품 종목
                    search_saving = ["예금", "적금", "통장", "저금"]
                    search_card = "카드"
                    search_loan = "대출"
                    search_invest = "펀드"

                    event_else = "기타"
                    product_Event = event_else

                    if any(word in product_Name for word in search_saving):
                        product_Event = "저축"
                    elif search_card in product_Name:
                        product_Event = "카드"
                    elif search_loan in product_Name:
                        product_Event = "대출"
                    elif search_invest in product_Name:
                        product_Event = "투자"

                    # 가입 대상
                    target = "청년"
                    product_target = "청년" if target in product_Name else "기타"

                    # 저장 과정
                    product_Dic = {
                        'product_no': num,
                        'product_bank': product_bank,
                        'product_type': product_Event,
                        'join_target': product_target,
                        'product_name': product_Name,
                        'product_file': product_body
                    }
                    products_List.append(product_Dic)
                    driver.back() # 반복문이 끝나면 드라이버 종료
                    time.sleep(1) # 페이지 로딩 대기
                except Exception as e:
                    print(f"Error occurred: {e}")
                    driver.back() # 반복문이 끝나면 드라이버 종료
                    time.sleep(1) # 페이지 로딩 대기
            else:
                break

        # 다음 페이지로 이동
        next_page = driver.find_elements(By.CSS_SELECTOR, '.pageArea a') # 다음 페이지로 넘어가는 태그를 담은 리스트 형태의 변수
        if i < len(next_page):
            try:
                next_page[i].click() # 페이지 클릭
                time.sleep(2)  # 페이지 로딩 대기
            except Exception as e:
                print(f"Error occurred while moving to the next page: {e}")

    driver.quit() 

    # DataCrawl() # 함수 실행
    df = pd.DataFrame(products_List) # 추출한 자료들을 데이터프레임으로 변경

    # 컬럼 순서를 조정하여 CLOB 컬럼을 마지막에 위치
    df = df[['product_no', 'product_bank', 'product_name', 'product_type', 'join_target', 'product_file']]
    df = df.sort_values(by='product_no') # 파일 생성전 데이터들을 product_no를 기준으로 오름차순 정렬
    df.to_csv("D:/Human_Project/tm_django/vita/tm_Project/consumer_portal.csv", index=False, encoding='utf-8-sig') # UTF-8언어로 csv파일 생성

# 데이터베이스에 csv파일의 데이터 insert해주는 함수
def Insert():
    try:
        bank = pd.read_csv('D:/Human_Project/tm_django/vita/tm_Project/consumer_portal.csv') # csv파일을 읽어서 변수 생성

        path = 'oracle+oracledb://chatbot:12345@localhost:1521/?service_name=xe' # 오라클 드라이버 경로
        engine = create_engine(path)
        orcl.init_oracle_client()

        bank = bank.astype({'product_no': 'int32'}) # product_no(첫번째 컬럼) 데이터 형태를 int32로 변경
        bank = bank.sort_values(by='product_no')


        print("Connected to database successfully.")
        bank.to_sql(
            name='PRODUCT_INFO',
            con=engine,
            if_exists='append',
            index=False,
        )
        print("Data inserted successfully.")
    except Exception as e:
        print(f"Error occurred during database insertion: {e}")