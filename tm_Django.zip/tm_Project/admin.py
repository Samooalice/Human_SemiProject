from django.contrib import admin
from tm_Project.models import Tm_Prject

# Register your models here.
@admin.register(Tm_Prject)
class MypwAdmin(admin.ModelAdmin):
    list_display = ('id', 'urlname', 'pw')