from django.apps import AppConfig


class TmProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tm_Project'
