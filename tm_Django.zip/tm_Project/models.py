from django.db import models

# Create your models here.
class Tm_Prject(models.Model):
    urlname = models.CharField('URLNAME', max_length=100, blank=True, unique=True)
    pw = models.CharField('PW', max_length=100, blank=True)

    def __str__(self):
        return self.urlname