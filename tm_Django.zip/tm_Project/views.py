from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
from django.http import HttpResponse
import json
import plotly.express as px
from .chartData import showChart
from tm_Project import finance
from tm_Project import openapiCrawl
from django.http import FileResponse
import os
from django.conf import settings

user_Dic = {'age': '', 'sub': '', 'bank':''}
class Memb:
    def __init__(self, age, sub, bank):
        self.age = age
        self.sub = sub
        self.bank = bank

    def toDict(self):
        return {
            "age": self.age,
            "sub": self.sub,
            "bank": self.bank
        }

# 바로가기 버튼 생성
def create_quick_reply(label, block_id):
    quick_reply = {
        "label": label,
        "action": "block",
        "blockId": block_id
    }
    return quick_reply

# 나이 : 네 선택했을때
@method_decorator(csrf_exempt, name='dispatch')
class getYoung(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "실버 상품은 제외하겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(1/3)", "664d6ba126296c3bea94a4fd")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["age"] = '청년'
        print(user_Dic)
        return JsonResponse(response)

# 나이 : 아니오 선택했을때
@method_decorator(csrf_exempt, name='dispatch')
class getSilver(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "실버 상품을 위주로 소개해 드리겠습니다."
                            
                        }
                    }
                ]
            }
            
        }
        
        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(1/3)", "664d6ba126296c3bea94a4fd")
        ]
        response["template"]["quickReplies"] = quick_replies
        
        user_Dic["age"] = '실버'
        print(user_Dic)
        return JsonResponse(response)

# 나이 : 선택안함 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getAge_Else(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "모든 나이대의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(1/3)", "664d6ba126296c3bea94a4fd")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["age"] = '나이_선택안함'
        print(user_Dic)
        return JsonResponse(response)
    
# 성향 : 저축 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getSaving(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "저축 관련 상품 위주로 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(2/3)", "664d803c2b2f2f1765b0ce3e")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["sub"] = '저축'
        print(user_Dic)
        return JsonResponse(response)

# 성향 : 카드 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getCard(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "카드 관련 상품 위주로 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(2/3)", "664d803c2b2f2f1765b0ce3e")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["sub"] = '카드'
        print(user_Dic)
        return JsonResponse(response)

# 성향 : 투자 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getInvest(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "투자 관련 상품 위주로 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(2/3)", "664d803c2b2f2f1765b0ce3e")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["sub"] = '투자'
        print(user_Dic)
        return JsonResponse(response)
    
# 성향 : 대출 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getLoan(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "대출 관련 상품 위주로 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(2/3)", "664d803c2b2f2f1765b0ce3e")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["sub"] = '대출'
        print(user_Dic)
        return JsonResponse(response)
    
# 성향 : 선택안함 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getSub_Else(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "모든 종목의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(2/3)", "664d803c2b2f2f1765b0ce3e")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["sub"] = '성향_선택안함'
        print(user_Dic)
        return JsonResponse(response)
    
# 은행 : 국민 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getbank_Kook(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "국민 은행의의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(3/3)", "6648b6c12b2f2f1765aff92b")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["bank"] = 'KB국민은행'
        print(user_Dic)
        return JsonResponse(response)
    
# 은행 : 신한 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getbank_Sin(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "신한 은행의의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(3/3)", "6648b6c12b2f2f1765aff92b")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["bank"] = '신한은행'
        print(user_Dic)
        return JsonResponse(response)
    
# 은행 : 우리 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getbank_Woo(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "우리 은행의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(3/3)", "6648b6c12b2f2f1765aff92b")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["bank"] = '우리은행'
        print(user_Dic)
        return JsonResponse(response)
    
# 은행 : 하나 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getbank_Han(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "하나 은행의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(3/3)", "6648b6c12b2f2f1765aff92b")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["bank"] = '하나은행'
        print(user_Dic)
        return JsonResponse(response)

    
# 은행 : 기타 선택했을때   
@method_decorator(csrf_exempt, name='dispatch')
class getbank_Else(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "simpleText": {
                            "text": "모든 은행의 상품을 보여드리겠습니다."
                        }
                    }
                ]
            }
        }

        # QuickReplies 설정
        quick_replies = [
            create_quick_reply("다음으로 이동(3/3)", "6648b6c12b2f2f1765aff92b")
        ]
        response["template"]["quickReplies"] = quick_replies
        user_Dic["bank"] = '은행_선택안함'
        print(user_Dic)
        return JsonResponse(response)

# 결과창 띄우기
@method_decorator(csrf_exempt, name='dispatch')
class getResult(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "basicCard": {
                        "title": "결과 확인",
                        "description": f"고객님의 선택 결과\n - 나이 : {user_Dic.get('age')}\n - 성향 : {user_Dic.get('sub')}\n - 은행 : {user_Dic.get('bank')}",
                        "thumbnail": {
                            "imageUrl": 'https://img.hankyung.com/photo/202110/01.27883728.1.jpg'
                            # "imageUrl": "https://t1.kakaocdn.net/openbuilder/sample/lj3JUcmrzC53YIjNDkqbWK.jpg"
                        },
                        "buttons": [
                            {
                            "action": "webLink",
                            "label": "결과보기",
                            "webLinkUrl": "http://58.72.151.124:6004/tm/getJsonVO.tm"
                            },
                            {
                            "action":  "block",
                            "label": "처음으로",
                            "blockId": "6648b5dc2260b1573785f47a"
                            }
                        ]
                        }
                    }
                ]
            }
        }
        return JsonResponse(response)

# 결과창 띄우기
@method_decorator(csrf_exempt, name='dispatch')
class showResultChart(View):
    def post(self, request, *args, **kwargs):
        request_body = json.loads(request.body)

        # 응답 메시지 구성
        response = {
            "version": "2.0",
            "template": {
                "outputs": [
                    {
                        "basicCard": {
                        "title": "동향 살펴보기",
                        "description": "상품들 차트를 확인합니다.",
                        "thumbnail": {
                            "imageUrl": 'https://cdn.imweb.me/upload/S20210831e1fe150864c6c/0531224592c4c.png'
                            # "imageUrl": "https://t1.kakaocdn.net/openbuilder/sample/lj3JUcmrzC53YIjNDkqbWK.jpg"
                        },
                        "buttons": [
                            {
                            "action": "webLink",
                            "label": "결과보기",
                            "webLinkUrl": "http://58.72.151.124:6003/tm/showChart2/"
                            },
                            {
                            "action":  "block",
                            "label": "처음으로",
                            "blockId": "6648b5dc2260b1573785f47a"
                            }
                        ]
                        }
                    }
                ]
            }
        }
        return JsonResponse(response)

def serve_image(request):
    image_path = os.path.join(settings.MEDIA_ROOT, 'chat_img', 'card6.jpg')
    return FileResponse(open(image_path, 'rb'), content_type='image/jpeg')

def getSelectData(req):
    # result_Json = Memb(user_Dic.get('age'), user_Dic.get('sub'), user_Dic.get('bank'))
    # d1 = result_Json.toDict()

    return JsonResponse(user_Dic, json_dumps_params={'ensure_ascii': False})

def test_data(request):
    data = {
        "bank": "은행",
        "max_Tex": "최고금리",
        "min_Tex": "최저금리",
        "mid_Tex": "중간금리",
        "bank1": "국민은행",
        "bank2": "하나은행",
        "bank3": "우리은행",
        "bank4": "신한은행",
    }
    return JsonResponse(data, json_dumps_params={'ensure_ascii': False})

def chart1(req):
    tag_data1 = showChart.chart1()
    return render(req, 'tm_Project/chart1.html', {'tag_data1': tag_data1})

def chart2(req):
    tag_data2 = showChart.chart2()
    return render(req, 'tm_Project/chart2.html', {'tag_data2': tag_data2})

def chart2(req):
    tag_data2sm = showChart.chart2()
    return render(req, 'tm_Project/chart2.html', {'tag_data2': tag_data2sm})

def chart2sm(req):
    tag_data2sm = showChart.chart2sm()
    return render(req, 'tm_Project/chart2sm.html', {'tag_data2sm': tag_data2sm})


def chart3(req):
    tag_data3 = showChart.chart3()
    return render(req, 'tm_Project/chart3.html', {'tag_data3': tag_data3})

def chart3sm(req):
    tag_data3sm = showChart.chart3sm()
    return render(req, 'tm_Project/chart3sm.html', {'tag_data3sm': tag_data3sm})

def chart4(req):
    tag_data4 = showChart.depositchart()
    return render(req, 'tm_Project/chart4.html', {'tag_data4': tag_data4})

def chart4sm(req):
    tag_data4sm = showChart.depositchartsm()
    return render(req, 'tm_Project/chart4sm.html', {'tag_data4sm': tag_data4sm})

def chart5(req):
    tag_data5 = showChart.savingchart()
    return render(req, 'tm_Project/chart5.html', {'tag_data5': tag_data5})

def chart5sm(req):
    tag_data5sm = showChart.savingchartsm()
    return render(req, 'tm_Project/chart5sm.html', {'tag_data5sm': tag_data5sm})

def chart6(req):
    tag_data6 = showChart.annuitychart()
    return render(req, 'tm_Project/chart6.html', {'tag_data6': tag_data6})

def chart6sm(req):
    tag_data6sm = showChart.annuitychartsm()
    return render(req, 'tm_Project/chart6sm.html', {'tag_data6sm': tag_data6sm})


def crawl_data(request):
    finance.DataCrawl()
    finance.Insert()

    return HttpResponse("OK")

def crawling(resquest):
    openapiCrawl.Crawling()

    return HttpResponse("OK")