from django.urls import path
from tm_Project import views

urlpatterns = [
    path('kkoChat_ageYes.tm/', views.getYoung.as_view(), name='kkoChat_ageYes'),
    path('kkoChat_ageNo.tm/', views.getSilver.as_view(), name='kkoChat_ageNo'),
    path('kkoChat_ageElse.tm/', views.getAge_Else.as_view(), name='kkoChat_ageElse'),

    path('kkoChat_subSave.tm/', views.getSaving.as_view(), name='kkoChat_subSave'),
    path('kkoChat_subCard.tm/', views.getCard.as_view(), name='kkoChat_subCard'),
    path('kkoChat_subInvest.tm/', views.getInvest.as_view(), name='kkoChat_subInvest'),
    path('kkoChat_subLoad.tm/', views.getLoan.as_view(), name='kkoChat_subLoad'),
    path('kkoChat_subElse.tm/', views.getSub_Else.as_view(), name='kkoChat_subElse'),

    path('kkoChat_bank_Kook.tm/', views.getbank_Kook.as_view(), name='kkoChat_bankKook'),
    path('kkoChat_bank_Sin.tm/', views.getbank_Sin.as_view(), name='kkoChat_bankSin'),
    path('kkoChat_bank_Woo.tm/', views.getbank_Woo.as_view(), name='kkoChat_bankWoo'),
    path('kkoChat_bank_Han.tm/', views.getbank_Han.as_view(), name='kkoChat_bankHan'),
    path('kkoChat_bank_Else.tm/', views.getbank_Else.as_view(), name='kkoChat_bankElse'),

    path('kkoChat_Result.tm/', views.getResult.as_view(), name='kkoChat_result'),
    path('kkoChat_ShowChart.tm/', views.showResultChart.as_view(), name='kkoChat_showChart'),

    path('media/chat_img/card6.jpg/', views.serve_image, name='card6_image'),

    path('result_Json.tm/', views.getSelectData, name='getData'),

    # path('showChart.tm/', views.chart1, name='chart1'),
    path('showChart1.tm/', views.chart1, name='chart1'),
    path('showChart2.tm/', views.chart2, name='chart2'),
    path('showChart2sm.tm/', views.chart2sm, name='chart2sm'),
    path('showChart3.tm/', views.chart3, name='chart3'),
    path('showChart3sm.tm/', views.chart3sm, name='chart3sm'),
    path('showChart4.tm/', views.chart4, name='chart4'),
    path('showChart4sm.tm/', views.chart4sm, name='chart4sm'),
    path('showChart5.tm/', views.chart5, name='chart5'),
    path('showChart5sm.tm/', views.chart5sm, name='chart5sm'),
    path('showChart6.tm/', views.chart6, name='chart6'),
    path('showChart6sm.tm/', views.chart6sm, name='chart6'),

    path('apicrawl.tm/', views.crawling, name='openapiCrawl'),
    path('crawl.tm/', views.crawl_data, name='finance'),
]