class Memb:
    def __init__(self, age, sub, bank):
        self.age = age
        self.sub = sub
        self.bank = bank

    def toDict(self):
        return{
            'age' : self.age,
            'sub' : self.sub,
            'bank' : self.bank
        }